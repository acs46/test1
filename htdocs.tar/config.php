<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'astuart';
$dbpass = 'secret';
$dbname = 'sampdb';
?>
