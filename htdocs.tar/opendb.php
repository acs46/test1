<?php

// This is an example opendb.php

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname); 

// Check connection

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
