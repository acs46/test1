<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="p1.php">
  <p>&nbsp;</p>
  <h1 align="center">Presidential Seach Form</h1>
  <div align="center">
    <table width="490" height="211" border="0">
      <tr>
        <td>Search for:</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><label>
          <input type="text" name="searchterm" id="searchterm" />
        </label></td>
        <td>in 
          <label>
            <select name="search_item" id="search_item">
              <option value="last_name">Last Name</option>
              <option value="first_name">First Name</option>
              <option value="city">City</option>
              <option value="state">State</option>
              <option value="birth">Birth</option>
              <option value="death">Death</option>
              <option value="all">ALL</option>
            </select>
        </label></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Display 
          <label>
            <select name="results" id="results">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="5">5</option>
              <option value="10" selected="selected">10</option>
              <option value="50">50</option>
            </select>
        results per page</label></td>
        <td>Sort by: 
          <select name="sortby" size="1" id="sortby">
            <option value="first_name">First Name</option>
            <option value="last_name" selected="selected">Last Name</option>
        </select></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
          <div align="center">
            <input name="Submit" type="submit" id="Submit" value="Submit" />
        </div></td>
        <td>
          <div align="center">
            <input type="reset" name="Reset" id="Reset" value="Reset" />
        </div></td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </div>
  <p align="center">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
