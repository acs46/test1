<?php

include 'configtdb.php'; 
include 'opentdb.php';

$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Jane', 'Doe', 'jane@example.com')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
