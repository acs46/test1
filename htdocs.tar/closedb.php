<?php
// an example of closedb.php
// it does nothing but closing
// a mysql database connection

$conn->close();
//mysql_close($conn);
?>


