<?php
// This is an example of config.php
$servername = "localhost"; 
$username = "root";
$password = "root";
$dbname = "myDB";
?>
