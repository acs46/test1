<html>
<?php
include 'config.php';
include 'opendb.php';

$searchterm = '\'%'.trim($_POST['searchterm']).'%\'';
$searchitem = $_POST['search_item'];
$results = $_POST['results'];
$sortby = $_POST['sortby'];

echo "$searchterm,$searchitem,$results,$sortby<br>";
//print "$searchterm<br>$searchitem<br>$results<br>$sortby<br>";



 if ($_POST['search_item'] == 'all') {
                        $querylist1 =         "(last_name  like $searchterm or
                                                first_name like $searchterm or
                                                city       like $searchterm or
                                                birth      like $searchterm or
                                                death      like $searchterm or
                                                state      like $searchterm)";
                                            }

        else {          $querylist1 = "$searchitem like $searchterm";              }

print "Querylist1= ".$querylist1."<br>";

// Show the Presidents in an HTML <table>
  function displayPres($result)
  {
	$bgflag = 1;
     print "<h1 align=center>Presidential Search Results</h1>";

     // Start a table, with column headers
     // Until there are no rows in the result set, fetch a row into
     // the $row array and ...
     // ... and print out each of the attributes in that row as a
     // separate TD (Table Data).

        if ($result->num_rows > 0) {

          echo "<table align=center cellpadding=1 cellspacing=5>";


       	  echo "\n<tr>
		<th>Last Name</th>
                <th>First Name</th>
                <th>Suffix</th>
                <th>City</th>
                <th>State</th>
                <th>Birth</th>
                <th>Death</th></tr>";

  	  while($row = $result->fetch_assoc()) {                                        
		 if ($bgflag==1)
               		{$bgnum = "FDFDF0";}
           	 else 	{$bgnum = "FFFFCC";}
    
       		echo 	"<tr bgcolor=$bgnum><td>".$row["last_name"].
                	"</td><td>".$row["first_name"].
                	"</td><td>".$row["suffix"].
               		"</td><td>".$row["city"].
                	"</td><td>".$row["state"].
                	"</td><td>".$row["birth"].
                	"</td><td>".$row["death"].
                	"</td></tr>" ;
			$bgflag*=-1;
						}
       } else {
    		echo 	"0 results";
                  }
		echo "</table>";
        
    }    
     
//$sql = "SELECT last_name, first_name, suffix, city, state, birth, death FROM president";
$sql = "SELECT * FROM president where ".$querylist1." order by ".$sortby." limit ".$results;



print "\$sql =".$sql;
$result = $conn->query($sql);

echo "<form align=center>";

displayPres($result);

include 'closedb.php';

echo "  <input type=\"button\" align=center value=\"Return\" onclick=\"history.back()\">";
echo "</form>";
?>

</html>






 
