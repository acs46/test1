<?php
//include 'config.php';
//include 'opendb.php';
  DEFINE('DB_USERNAME', 'root');
  DEFINE('DB_PASSWORD', 'root');
  DEFINE('DB_HOST', '127.0.0.1');
  DEFINE('DB_DATABASE', 'performance_schema');
//  DEFINE('DB_DATABASE', 'DogT');

$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

//  if (mysqli_connect_error()) {
//    die('Connect Error ('.mysqli_connect_errno().') '.mysqli_connect_error());
//  }

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$con=mysqli_connect('localhost','root','root','DogT');

mysqli_query($con,"SELECT * FROM breeds");

  echo 'Connected successfully. Hey All';


$query = "SELECT * from breeds";

if (!($result = @ mysqli_query ($query, $con)))
  echo 'Error could not get results';


print($result);

mysqli_close($con);
//include 'closedb.php


//$mysqli->close();
?>
