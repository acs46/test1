<html>

<?php
include 'config.php';
include 'opendb.php';


$searchfield = $_POST['searchterm'];
$searchitem = $_POST['search_item'];
$results = $_POST['results'];
$sortby = $_POST['sortby'];

echo "$searchfield,$searchitem,$results,$sortby<br>";
//print "$searchfield<br>$searchitem<br>$results<br>$sortby<br>";

// Show the Presidents in an HTML <table>
  function displayPres($result)
  {

     print "<h1>Our Presidents</h1>\n";

     // Start a table, with column headers
  
     // Until there are no rows in the result set, fetch a row into
     // the $row array and ...

        // ... and print out each of the attributes in that row as a
        // separate TD (Table Data).
        if ($result->num_rows > 0) {
    // output data of each row
          echo "<table><tr><th>Last Name</th>
                                        <th>First Name</th>
                                        <th>Suffix</th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Birth</th>
                                        <th>Death</th></tr>";
    while($row = $result->fetch_assoc()) {                                        
    
        echo "<tr><td>".$row["last_name"].
                "</td><td>".$row["first_name"].
                "</td><td>".$row["suffix"].
                "</td><td>".$row["city"].
                "</td><td>".$row["state"].
                "</td><td>".$row["birth"].
                "</td></tr>" ;
                                                                 }
        } else {
    echo "0 results";
                  }
echo "</table>";
        
    }    
     
$sql = "SELECT last_name, first_name, suffix, city, state, birth, death FROM president";
$result = $conn->query($sql);


displayPres($result);

include 'closedb.php';
?>

</html>






 